<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            // Columna nullable para permitir usuarios sin tramitador asignado
            $table->unsignedBigInteger('tramitador_id')->nullable()->after('id');

            // FK auto‐referenciada a users.id
            $table->foreign('tramitador_id')
                ->references('id')
                ->on('users')
                ->onDelete('set null');
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['tramitador_id']);
            $table->dropColumn('tramitador_id');
        });
    }
};
